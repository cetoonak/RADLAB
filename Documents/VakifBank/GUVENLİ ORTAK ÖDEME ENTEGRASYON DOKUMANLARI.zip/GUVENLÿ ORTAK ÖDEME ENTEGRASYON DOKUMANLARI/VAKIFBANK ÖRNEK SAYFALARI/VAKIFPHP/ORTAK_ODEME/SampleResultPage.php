﻿<?php

//XML sorgu cevabını parse eder.
function SonucuOku($result)
{
	$resultDocument = new DOMDocument();
	$resultDocument->loadXML($result);

	//Rc Bilgisi okunuyor	
	$RcNode = $resultDocument->getElementsByTagName("Rc")->item(0);				
	$Rc = "";	
	if( $RcNode != null )
		$Rc = $RcNode->nodeValue;				
	
	//AuthCode Bilgisi okunuyor
	$AuthCodeNode = $resultDocument->getElementsByTagName("AuthCode")->item(0);				
	$AuthCode = "";	
	if( $AuthCodeNode != null )
		$AuthCode = $AuthCodeNode->nodeValue;
	
	//Message Bilgisi okunuyor
	$MessageNode = $resultDocument->getElementsByTagName("Message")->item(0);				
	$Message = "";	
	if( $MessageNode != null )
		$Message = $MessageNode->nodeValue;
	
	//TransactionId Bilgisi okunuyor
	$TransactionIdNode = $resultDocument->getElementsByTagName("TransactionId")->item(0);				
	$TransactionId = "";	
	if( $TransactionIdNode != null )
		$TransactionId = $TransactionIdNode->nodeValue;
	
	//PaymentToken Bilgisi okunuyor
	$PaymentTokenNode = $resultDocument->getElementsByTagName("PaymentToken")->item(0);				
	$PaymentToken = "";	
	if( $PaymentTokenNode != null )
		$PaymentToken = $PaymentTokenNode->nodeValue;
	
	//MaskedPan Bilgisi okunuyor
	$MaskedPanNode = $resultDocument->getElementsByTagName("MaskedPan")->item(0);				
	$MaskedPan = "";	
	if( $MaskedPanNode != null )
		$MaskedPan = $MaskedPanNode->nodeValue;
	
	//ErrorCode Bilgisi okunuyor
	$ErrorCodeNode = $resultDocument->getElementsByTagName("ErrorCode")->item(0);				
	$ErrorCode = "";	
	if( $ErrorCodeNode != null )
		$ErrorCode = $ErrorCodeNode->nodeValue;

	// Sonuç dizisi oluşturuluyor
	$result = array
	(
		"Rc"=>$Rc,
		"AuthCode"=>$AuthCode,
		"Message"=>$Message,
		"TransactionId"=>$TransactionId,
		"PaymentToken"=>$PaymentToken,
		"MaskedPan"=>$MaskedPan,
		"ErrorCode"=>$ErrorCode
	);
	return $result;
}

$Rc = $_GET["Rc"];
$Message = $_GET["Message"];
$TransactionId = $_GET["TransactionId"];
$PaymentToken = $_GET["PaymentToken"];
$HostMerchantId = "000000000000471";
$Password = "123456";
$PostURL = "";				//Dokümanda belirtilen URL

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$PostURL);
curl_setopt($ch, CURLOPT_POST, TRUE);
curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);
curl_setopt($ch,CURLOPT_HTTPHEADER,array("Content-Type"=>"application/x-www-form-urlencoded"));
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Accept: application/xml'));
curl_setopt($ch,CURLOPT_RETURNTRANSFER,TRUE);
curl_setopt($ch, CURLOPT_POSTFIELDS,"TransactionId=$TransactionId"
                . "&PaymentToken=$PaymentToken"
                . "&HostMerchantId=$HostMerchantId"
                . "&Password=$Password");
curl_setopt($ch, CURLOPT_TIMEOUT, 59);
$result = curl_exec($ch);
curl_close($ch);


Echo "<h2>Islem Sonucu</h2>";
Echo "<p>Rc=$Rc</p>";
Echo "<p>Message=$Message</p>";
$sonuc = SonucuOku($result);
Echo "<h2>Sorgulama Parametreleri</h2>";
Echo "<p>TransactionId=$TransactionId"
                . "&PaymentToken=$PaymentToken"
                . "&HostMerchantId=$HostMerchantId"
                . "&Password=$Password</p>";
Echo "<h2>Sorgulama Sonucu</h2>";
Echo "<p>Rc: ".$sonuc["Rc"]."</p>";
Echo "<p>AuthCode: ".$sonuc["AuthCode"]."</p>";
Echo "<p>Message: ".$sonuc["Message"]."</p>";
Echo "<p>TransactionId: ".$sonuc["TransactionId"]."</p>";
Echo "<p>PaymentToken: ".$sonuc["PaymentToken"]."</p>";
Echo "<p>MaskedPan: ".$sonuc["MaskedPan"]."</p>";
Echo "<p>ErrorCode: ".$sonuc["ErrorCode"]."</p>";
?>