﻿<?php
error_reporting(E_ALL ^ E_NOTICE);

function SonucuOku($result)
{
	$resultDocument = new DOMDocument();
	$resultDocument->loadXML($result);

	//PaymentToken Bilgisi okunuyor	
	$PaymentTokenNode = $resultDocument->getElementsByTagName("PaymentToken")->item(0);				
	$PaymentToken = "";	
	if( $PaymentTokenNode != null )
		$PaymentToken = $PaymentTokenNode->nodeValue;
	
	//CommonPaymentUrl Bilgisi okunuyor
	$CommonPaymentUrlNode = $resultDocument->getElementsByTagName("CommonPaymentUrl")->item(0);				
	$CommonPaymentUrl = "";	
	if( $CommonPaymentUrlNode != null )
		$CommonPaymentUrl = $CommonPaymentUrlNode->nodeValue;
	
	//ErrorCode Bilgisi okunuyor
	$ErrorCodeNode = $resultDocument->getElementsByTagName("ErrorCode")->item(0);				
	$ErrorCode = "";	
	if( $ErrorCodeNode != null )
		$ErrorCode = $ErrorCodeNode->nodeValue;

	// Sonuç dizisi oluşturuluyor
	$result = array
	(
		"CommonPaymentUrl"=>$CommonPaymentUrl,
		"PaymentToken"=>$PaymentToken,
		"ErrorCode"=>$ErrorCode
	);
	return $result;	
}

if ($_POST["hdnMode"] != "RESULT") {
   ?>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=windows-1254">
        <title>Vakifbank Ortak Odeme</title>
    </head>
	<style>
.input_yeni {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 9pt;
	font-weight: bold;
	color: #666666;
	background-color: #FFFFFF;
	padding: 5px;
	border: 1px solid #CCCCCC;
}
.Basliklar {
	font-family: Tahoma;
	font-size: 9pt;
	font-weight: bold;
	color: #666666;
	padding-left: 10px;
	border-bottom-width: 1px;
	border-bottom-style: solid;
	border-bottom-color: #EBEBEB;
	padding-top: 2px;
	text-align: right;
}
.AltCizgi {
	font-family: Tahoma;
	font-size: 9pt;
	font-weight: normal;
	color: #666666;
	border-bottom-width: 1px;
	border-bottom-style: solid;
	border-bottom-color: #EBEBEB;
	padding-top: 2px;
	padding-bottom: 2px;
	padding-left: 5px;
}
</style>
    <body>


        <form id="iPayTestForm" action="" method="POST">
            <input type="hidden" name="hdnMode" value="RESULT">
            <table border="0" id="table1" cellpadding="0" cellspacing="0">
               <tr>
			<td width="10" height="10" bgcolor="#FBFBFB" class="Basliklar">&nbsp;</td>
			<td width="1" bgcolor="#FBFBFB" class="AltCizgi">&nbsp;</td>
			<B><td bgcolor="#FBFBFB" class="AltCizgi">Vakifbank Ortakodeme islem Uye is yeri bilgileri</td></B>
		</tr>
		<tr>
			<td width="100" height="25" class="Basliklar">Service URL</td>
			<td width="1" class="AltCizgi">:</td>
			<td class="AltCizgi">
			<input class="input_yeni" type="text" name="ServiceUrl" size="80" value=""></td>
		</tr>
		<tr>
			<td width="100" height="25" class="Basliklar">Uye Isyeri No</td>
			<td width="1" class="AltCizgi">:</td>
			<td class="AltCizgi">
			<input class="input_yeni" type="text" name="HostMerchantId" size="49" value="0"></td>
		</tr>
		<tr>
			<td width="100" height="25" class="Basliklar">İsyeri Sifre</td>
			<td width="1" class="AltCizgi">:</td>
			<td class="AltCizgi">
			<input class="input_yeni" type="text" name="MerchantPassword" size="49" value="0"></td>
		</tr>
		<tr>
			<td width="100" height="25" class="Basliklar">Tutar</td>
			<td width="1" class="AltCizgi">:</td>
			<td class="AltCizgi">
			<input class="input_yeni" type="text" name="Amount" size="49" value="1.00"></td>
		</tr>
		<tr>
			<td width="100" height="25" class="Basliklar">Taksit sayısı</td>
			<td width="1" class="AltCizgi">:</td>
			<td class="AltCizgi">
			<input class="input_yeni" type="text" name="InstalmentCount" size="49" value=""></td>
		</tr>
		<tr>
			<td width="100" height="25" class="Basliklar">Döviz Turu</td>
			<td width="1" class="AltCizgi">:</td>
			<td class="AltCizgi">
			<input class="input_yeni" type="text" name="AmountCode" size="49" value="840"></td>
		</tr>
		<tr>
			<td width="100" height="25" class="Basliklar">Sıparıs No</td>
			<td width="1" class="AltCizgi">:</td>
			<td class="AltCizgi">
			<input class="input_yeni" type="text" name="TransactionId" size="49" value="OTOMATIK URETILMEKTEDIR"></td>
		</tr>
		<tr>
			<td width="100" height="25" class="Basliklar">Order ID</td>
			<td width="1" class="AltCizgi">:</td>
			<td class="AltCizgi">
			<input class="input_yeni" type="text" name="OrderId" size="49" value=""></td>
		</tr>
		<tr>
			<td width="100" height="25" class="Basliklar">Order DESC</td>
			<td width="1" class="AltCizgi">:</td>
			<td class="AltCizgi">
			<input class="input_yeni" type="text" name="OrderDescription" size="80" value=""></td>
		</tr>
		<tr>
			<td width="100" height="25" class="Basliklar">TransactionType</td>
			<td width="1" class="AltCizgi">:</td>
			<td class="AltCizgi">
			<input class="input_yeni" type="text" name="TransactionType" size="49" value="Sale"></td>
		</tr>
		<tr>
			<td width="100" height="25" class="Basliklar">IsSecure</td>
			<td width="1" class="AltCizgi">:</td>
			<td class="AltCizgi">
			<input class="input_yeni" type="text" name="IsSecure" size="49" value="true"></td>
		</tr>
		<tr>
			<td width="100" height="25" class="Basliklar">AllowNotEnrolledCard</td>
			<td width="1" class="AltCizgi">:</td>
			<td class="AltCizgi">
			<input class="input_yeni" type="text" name="AllowNotEnrolledCard" size="49" value="false"></td>
		</tr>
		<tr>
			<td width="100" height="25" class="Basliklar">HostTerminalId</td>
			<td width="1" class="AltCizgi">:</td>
			<td class="AltCizgi">
			<input class="input_yeni" type="text" name="HostTerminalId" size="49" value="0"></td>
		</tr>
		<tr>
			<td width="100" height="25" class="Basliklar">SuccessURL</td>
			<td width="1" class="AltCizgi">:</td>
			<td class="AltCizgi">
			<input class="input_yeni" type="text" name="SuccessURL" size="49" value=""></td>
		</tr>
		<tr>
			<td width="100" height="25" class="Basliklar">FailureURL</td>
			<td width="1" class="AltCizgi">:</td>
			<td class="AltCizgi">
			<input class="input_yeni" type="text" name="FailureURL" size="49" value=""></td>
		</tr>
                
                <br/> <input type="submit">
            </table>
        </form>

    </body>

</html>
<?php

} else {

$sendTrnxUrl = ""	//CommonPaymentUrl parametresi ile yanıt mesajında iletilen url
+"?Ptkn=";
$PostUrl = "";		//Dokümanda yer alan API Url'si
$TransactionId = "SIPARIS12345".time();/*değer uretıyoruz*/
$Amount = $_POST["Amount"];
$AmountCode = $_POST["AmountCode"];
$HostMerchantId = $_POST["HostMerchantId"];
$MerchantPassword = $_POST["MerchantPassword"];
$InstalmentCount = $_POST["InstalmentCount"];
$OrderId = $_POST["OrderId"];
$OrderDescription = $_POST["OrderDescription"];
$TransactionType = $_POST["TransactionType"];
$IsSecure = $_POST["IsSecure"];
$AllowNotEnrolledCard = $_POST["AllowNotEnrolledCard"];
$HostTerminalId = $_POST["HostTerminalId"];
$SuccessURL = $_POST["SuccessURL"];
$FailureURL = $_POST["FailureURL"];

$ch = curl_init();
                                                               
curl_setopt($ch, CURLOPT_URL,$PostUrl);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Accept: application/xml'));
curl_setopt($ch, CURLOPT_POSTFIELDS,"HostMerchantId=$HostMerchantId"
                . "&AmountCode=$AmountCode"
                . "&Amount=$Amount"
                . "&MerchantPassword=$MerchantPassword"
                . "&TransactionId=$TransactionId"
                . "&OrderID=$OrderId" 
                . "&OrderDescription=$OrderDescription" 
                . "&InstallmentCount=$InstalmentCount"
                . "&TransactionType=$TransactionType"
                . "&IsSecure=$IsSecure" 
                . "&AllowNotEnrolledCard=$AllowNotEnrolledCard"
                . "&HostTerminalId=$HostTerminalId" 
                . "&SuccessURL=$SuccessURL"
                . "&FailURL=$FailureURL");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_TIMEOUT, 59);
$result = curl_exec($ch);
curl_close($ch);
											
/*dönen XML değeri parse ediliyor.*/
$sonuc = SonucuOku($result);
if ($sonuc["ErrorCode"] == null) {
	echo '<h1>Sonuç değerleri</h1>';
	Echo 'PaymentToken: ' . $sonuc["PaymentToken"] . '<br/>';
	Echo 'CommonPaymentUrl: ' . $sonuc["CommonPaymentUrl"] . '<br/>';
	$newURL = $sendTrnxUrl.$sonuc["PaymentToken"];
	Echo $newURL;
	header('Location: '.$newURL);
} else {
	echo '<h1>Hata</h1>';
	Echo "Error Code: " . $sonuc["ErrorCode"];
}


}
?>