﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.Text;
using System.IO;

namespace PF.Vpos.CommonPayment.Sample
{
    public partial class SampleResultPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(Page.IsPostBack)
            {
                return;
            }

            WebRequest webRequest = WebRequest.Create("http://localhost:40450/api/VposTransaction");
            webRequest.ContentType = "application/x-www-form-urlencoded";
            webRequest.Method = "POST";

            //POST edilecek parametreler
            string queryparameters =
                "HostMerchantId=655500056"
                + "&Password=123456"
                + "&TransactionId=" + Request.QueryString["TransactionId"];

            byte[] bytes = Encoding.ASCII.GetBytes(queryparameters);

            //Request Hazırlama
            Stream wbStream = null;
            try
            {
                webRequest.ContentLength = bytes.Length;
                wbStream = webRequest.GetRequestStream();
                wbStream.Write(bytes, 0, bytes.Length);
            }
            finally
            {
                if (wbStream != null)
                {
                    wbStream.Close();
                }
            }

            //Request gönderip Cevap alma
            WebResponse webResponse = webRequest.GetResponse();
            string test = string.Empty;
            if (webResponse != null)
            {
                StreamReader sr = new StreamReader(webResponse.GetResponseStream());
                test = sr.ReadToEnd().Trim();
            }

            string message = "";
            string rc = "";
            string authCode = "";
            string msg = "";
            string transactionId = "";
            string ptkn = "";

            if (test.Contains("1 - "))
            {
                message = test.Replace("1 - ", "");
            }
            else
            {
                string[] resultArray = test.Replace("0 - ", "").Split(new char[] { '&' });

                foreach (var item in resultArray)
                {
                    string[] parameters = item.Split(new char[] { '=' });
                    foreach (var param in parameters)
                    {
                        if (parameters[0] == "RC")
                        {
                            rc = parameters[1];
                        }
                        if (parameters[0] == "AUTH_CODE")
                        {
                            authCode = parameters[1];
                        }
                        if (parameters[0] == "MSG")
                        {
                            msg = parameters[1];
                        }
                        if (parameters[0] == "TransactionId")
                        {
                            transactionId = parameters[1];
                        }
                        if (parameters[0] == "Ptkn")
                        {
                            ptkn = parameters[1];
                        }
                    }
                }
            }

            resultCodeLabel.Text = "ResultCode="+rc;
            authCodeLabel.Text = "AuthCode="+authCode;
            ptknLabel.Text = "PaymentToken="+ptkn;
            messageLabel.Text = "Message=" + message;
        }
    }
}