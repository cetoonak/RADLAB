﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.IO;
using System.Text;

namespace PF.Vpos.CommonPayment.Sample
{
    public partial class SampleCommonPaymentRegistration : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack)
            {
                return;
            }

            WebRequest webRequest = WebRequest.Create("");
            webRequest.ContentType = "application/x-www-form-urlencoded";
            webRequest.Method = "POST";

            //POST edilecek parametreler
            string parameters = "HostMerchantId=0"
                + "&AmountCode=949"
                + "&Amount=100"
                + "&MerchantPassword=0"
                + "&TransactionId=" + Guid.NewGuid().ToString("N") 
                + "&OrderID=" 
                + "&OrderDescription=" 
                + "&InstallmentCount="
                + "&TransactionType=Sale"
                + "&IsSecure=true" 
                + "&AllowNotEnrolledCard=false"
                + "&HostTerminalId=000123" 
                + "&ReturnUrl=http://localhost:4560/Result.aspx";

            byte[] bytes = Encoding.ASCII.GetBytes(parameters);

            //Request Hazırlama
            Stream wbStream = null;
            try
            {
                webRequest.ContentLength = bytes.Length;
                wbStream = webRequest.GetRequestStream();
                wbStream.Write(bytes, 0, bytes.Length);
            }
            finally
            {
                if (wbStream != null)
                {
                    wbStream.Close();
                }
            }

            //Request gönderip Cevap alma
            WebResponse webResponse = webRequest.GetResponse();
            string test = string.Empty;
            if (webResponse != null)
            {
                StreamReader sr = new StreamReader(webResponse.GetResponseStream());
                test = sr.ReadToEnd().Trim();
            }


            //Ortak ödemeyi açabileceğimiz token ı aldık.

            lblToken.Text = test.Replace("0 - ", "");
        }
    }
}